﻿This is the "Web service project v1" project template.
Refreshed in September 2017.
