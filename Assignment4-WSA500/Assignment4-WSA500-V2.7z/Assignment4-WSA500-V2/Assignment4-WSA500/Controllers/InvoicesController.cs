﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Assignment4_WSA500.Controllers
{
    public class InvoicesController : ApiController
    {
        // Attention 05 - Typical controller configuration...

        // Reference to the data manager
        // All methods return IHttpActionResult or void
        // Method construction is similar to what you know from ASP.NET MVC web apps

        // Reference to the data manager
        private Manager m = new Manager();

        // GET: api/Invoices
        public IHttpActionResult Get()
        {
            return Ok(m.InvoiceGetAll());
        }

        // GET: api/Invoices/5
        public IHttpActionResult Get(int? id)
        {
            // Attempt to locate the matching object
            var o = m.InvoiceGetOne(id.GetValueOrDefault());

            if (o == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(o);
            }
        }

        // POST: api/Invoices
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Invoices/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Invoices/5
        public void Delete(int id)
        {
        }
    }
}
